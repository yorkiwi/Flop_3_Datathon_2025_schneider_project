import numpy as np
import pandas as pd
import time
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

# ----------------------------- Evaluation function -----------------------------
def evaluate_model(model, X, y):
    preds = model.predict(X)
    return {
        "accuracy": accuracy_score(y, preds),
        "f1": f1_score(y, preds),
        "precision": precision_score(y, preds),
        "recall": recall_score(y, preds)
    }

# ----------------------------- Print Results Table -----------------------------
def print_results_table(model_name, metrics_dict, time_taken):
    print(f"\n📊 Performance Table for {model_name}")
    print("+----------------+-----------+")
    print("| Metric         | Value     |")
    print("+----------------+-----------+")
    for metric, value in metrics_dict.items():
        print(f"| {metric.capitalize():<14} | {value:<9.4f} |")
    print(f"| Time (s)       | {time_taken:<9.2f} |")
    print("+----------------+-----------+\n")

# ----------------------------- Main Function -----------------------------
def main():
    print("🔍 Loading dataset...")
    try:
        # Load data
        df = pd.read_csv("dataset.csv")
        if 'id' in df.columns:
            df = df.drop(columns=["id"])

        X = df.drop("target_variable", axis=1)
        y = df["target_variable"]

        # Scale features for consistency across models
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Split the data into 80% training and 20% test
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    except Exception as e:
        print(f"Error loading or processing the dataset: {e}")
        return

    # Models to train
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Random Forest": RandomForestClassifier(n_estimators=300, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(),
        "XGBoost": XGBClassifier(eval_metric="logloss", use_label_encoder=False),
        "LightGBM": LGBMClassifier(),
        "CatBoost": CatBoostClassifier(verbose=False),
        "KNN": KNeighborsClassifier(n_jobs=-1),
        "SVC": SVC(probability=True),
        "Naive Bayes": GaussianNB(),
        "MLP Neural Net": MLPClassifier(max_iter=500)
    }

    results = {}
    times = {}

    print("\n🚀 Training all models on training dataset...\n")
    for name, model in models.items():
        try:
            print(f"🔧 Training {name}...")
            start_time = time.time()

            # Train the model on the training set
            model.fit(X_train, y_train)

            # Record training time
            elapsed = time.time() - start_time
            times[name] = elapsed

            # Evaluate the model on the test set
            scores = evaluate_model(model, X_test, y_test)
            results[name] = scores

            print_results_table(name, scores, elapsed)

        except Exception as e:
            print(f"Error during training or evaluation for {name}: {e}")

    # ---------------------------------------------------------
    # 🔥 Print the TOP 4 MODELS sorted by F1 score
    # ---------------------------------------------------------
    print("\n🏆 TOP 4 MODELS (ranked by F1):\n")
    sorted_results = sorted(results.items(), key=lambda x: x[1]['f1'], reverse=True)
    top4 = sorted_results[:4]
    for rank, (model_name, metrics) in enumerate(top4, start=1):
        print(f"#{rank} → {model_name}")
        print(f"   Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}, "
              f"Precision: {metrics['precision']:.4f}, Recall: {metrics['recall']:.4f}, "
              f"Time: {times[model_name]:.6f}s\n")

    # ---------------------------------------------------------
    # ⏱ Print the BOTTOM 3 MODELS sorted by F1 score
    # ---------------------------------------------------------
    print("\n💔 BOTTOM 3 MODELS (ranked by F1):\n")
    bottom3 = sorted_results[-3:]  # Get the last 3 models with the lowest F1 score
    for rank, (model_name, metrics) in enumerate(bottom3, start=1):
        print(f"#{rank} → {model_name}")
        print(f"   Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}, "
              f"Precision: {metrics['precision']:.4f}, Recall: {metrics['recall']:.4f}, "
              f"Time: {times[model_name]:.6f}s\n")

    # ---------------------------------------------------------
    # ⏱ Print the 5 fastest algorithms
    # ---------------------------------------------------------
    print("\n⚡ Top 5 Fastest Algorithms (training + evaluation time):\n")
    sorted_times = sorted(times.items(), key=lambda x: x[1])
    top5_fastest = sorted_times[:5]
    for rank, (model_name, t) in enumerate(top5_fastest, start=1):
        metrics = results[model_name]
        print(f"#{rank} → {model_name}")
        print(f"   Time: {t:.2f}s, Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}, "
              f"Precision: {metrics['precision']:.4f}, Recall: {metrics['recall']:.4f}\n")

if __name__ == "__main__":
    main()
