import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier


def evaluate_model(model, X_test, y_test):
    preds = model.predict(X_test)
    return {
        "accuracy": accuracy_score(y_test, preds),
        "f1": f1_score(y_test, preds)
    }


def main():

    print("🔍 Loading dataset...")
    df = pd.read_csv("dataset.csv")

    df = df.drop(columns=["id"])  # remove non-predictive ID

    X = df.drop("target_variable", axis=1)
    y = df["target_variable"]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Random Forest": RandomForestClassifier(n_estimators=300),
        "Gradient Boosting": GradientBoostingClassifier(),
        "XGBoost": XGBClassifier(eval_metric="logloss"),
        "LightGBM": LGBMClassifier(),
        "CatBoost": CatBoostClassifier(verbose=False),
        "KNN": KNeighborsClassifier(),
        "SVC": SVC(probability=True),
        "Naive Bayes": GaussianNB(),
        "MLP Neural Net": MLPClassifier(max_iter=500)
    }

    results = {}

    print("\n🚀 Training all models...\n")
    for name, model in models.items():
        print(f"Training {name}...")
        model.fit(X_train, y_train)

        scores = evaluate_model(model, X_test, y_test)
        results[name] = scores

        print(f"{name} → Accuracy: {scores['accuracy']:.4f}, F1: {scores['f1']:.4f}\n")

    # ---------------------------------------------------------
    # 🔥 Print the TOP 4 MODELS sorted by F1 descending
    # ---------------------------------------------------------
    print("\n🏆 TOP 4 MODELS (ranked by F1):\n")

    sorted_results = sorted(
        results.items(),
        key=lambda x: x[1]['f1'],
        reverse=True
    )

    top4 = sorted_results[:4]

    for rank, (model_name, metrics) in enumerate(top4, start=1):
        print(f"#{rank} → {model_name}")
        print(f"   Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}\n")


if __name__ == "__main__":
    main()
