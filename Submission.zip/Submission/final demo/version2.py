import os
import time
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Ensure matplotlib doesn't try to open GUI windows
import matplotlib.pyplot as plt
import shap
from lime.lime_tabular import LimeTabularExplainer  # Import LimeTabularExplainer

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# ---------- CONFIG ----------
CSV_PATH = "dataset.csv"
OUTPUT_DIR = "explainability_outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

PDP_COLS = 3
MIN_UNIQUE_FOR_PDP = 5
PDP_PERCENTILES = (0.01, 0.99)

# ---------- HELPERS ----------
def evaluate_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred)
    }

def print_results_table(model_name, metrics_dict, time_taken):
    print(f"\n📊 Performance Table for {model_name}")
    print("+----------------+-----------+")
    print("| Metric         | Value     |")
    print("+----------------+-----------+")
    for metric, value in metrics_dict.items():
        print(f"| {metric.capitalize():<14} | {value:<9.4f} |")
    print(f"| Time (s)       | {time_taken:<9.2f} |")
    print("+----------------+-----------+\n")

# ---------- LOAD DATA ----------
df = pd.read_csv(CSV_PATH)
if "id" in df.columns:
    df = df.drop(columns=["id"])

feature_names = df.drop(columns=["target_variable"]).columns.tolist()
X = df.drop(columns=["target_variable"])
y = df["target_variable"]

# Scaling the features
scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=feature_names)

# Now apply the 80/20 split (80% for training, 20% for testing)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

# ============================================================
#                     XGBOOST
# ============================================================
print("Training XGBoost...")

# Train the XGBoost model using X_train and y_train
xgb = XGBClassifier(eval_metric="logloss", use_label_encoder=False, random_state=42)
t0 = time.time()
xgb.fit(X_train, y_train)  # Fit on the training data
t_xgb = time.time() - t0

# Predict using the test data (X_test)
y_pred_xgb = xgb.predict(X_test)  # Predict on the test data
metrics_xgb = evaluate_metrics(y_test, y_pred_xgb)  # Evaluate using y_test
print_results_table("XGBoost", metrics_xgb, t_xgb)

# ------------------ LIME Explanation for XGBoost ------------------------
explainer_xgb = LimeTabularExplainer(
    X_train.values,  # Use X_train as pandas DataFrame
    feature_names=feature_names,
    class_names=y.unique().astype(str),  # Target class names
    discretize_continuous=True
)

# Let's explain a few random predictions for XGBoost
for i in range(5):  # Change the number for more or fewer explanations
    print(f"\nExplaining XGBoost prediction for instance {i}")
    exp = explainer_xgb.explain_instance(X_test.iloc[i].values, xgb.predict_proba)
    exp.save_to_file(f"{OUTPUT_DIR}/xgb_lime_exp_{i}.html")
    exp.as_pyplot_figure()
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/xgb_lime_exp_{i}.png")
    plt.close()

# ============================================================
#                 RANDOM FOREST
# ============================================================
print("Training Random Forest...")

# Train the Random Forest model using X_train and y_train
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=12,
    max_features="sqrt",
    n_jobs=-1,
    random_state=42,
)
t0 = time.time()
rf.fit(X_train, y_train)  # Fit on the training data
t_rf = time.time() - t0

# Predict using the test data (X_test)
y_pred_rf = rf.predict(X_test)  # Predict on the test data
metrics_rf = evaluate_metrics(y_test, y_pred_rf)  # Evaluate using y_test
print_results_table("RandomForest", metrics_rf, t_rf)

# ------------------ LIME Explanation for Random Forest ------------------------
explainer_rf = LimeTabularExplainer(
    X_train.values,  # Use X_train as pandas DataFrame
    feature_names=feature_names,
    class_names=y.unique().astype(str),  # Target class names
    discretize_continuous=True
)

# Let's explain a few random predictions for Random Forest
for i in range(5):  # Change the number for more or fewer explanations
    print(f"\nExplaining Random Forest prediction for instance {i}")
    exp = explainer_rf.explain_instance(X_test.iloc[i].values, rf.predict_proba)
    exp.save_to_file(f"{OUTPUT_DIR}/rf_lime_exp_{i}.html")
    exp.as_pyplot_figure()
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/rf_lime_exp_{i}.png")
    plt.close()

# ============================================================
print("\nDone. Saved files in:", OUTPUT_DIR)
for f in os.listdir(OUTPUT_DIR):
    print(" -", f)
