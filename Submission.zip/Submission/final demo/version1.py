import os
import math
import time
import pandas as pd
import numpy as np

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import shap  # Import SHAP library

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.inspection import PartialDependenceDisplay
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# ---------- CONFIG ----------  
CSV_PATH = "dataset.csv"
OUTPUT_DIR = "explainability_outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

PDP_COLS = 3
MIN_UNIQUE_FOR_PDP = 5
PDP_PERCENTILES = (0.01, 0.99)

# ---------- HELPERS ----------
def evaluate_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred)
    }

def print_results_table(model_name, metrics_dict, time_taken):
    print(f"\n📊 Performance Table for {model_name}")
    print("+----------------+-----------+")
    print("| Metric         | Value     |")
    print("+----------------+-----------+")
    for metric, value in metrics_dict.items():
        print(f"| {metric.capitalize():<14} | {value:<9.4f} |")
    print(f"| Time (s)       | {time_taken:<9.2f} |")
    print("+----------------+-----------+\n")

def save_pdp_grid(model_name, model_for_pdp, X_for_pdp):
    Xf = X_for_pdp.astype(float)
    n_features = Xf.shape[1]
    cols = PDP_COLS
    rows = math.ceil(n_features / cols)

    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 4 * rows))
    axes = axes.flatten()

    plot_i = 0
    for feat in Xf.columns:
        if Xf[feat].nunique() <= MIN_UNIQUE_FOR_PDP:
            axes[plot_i].axis('off')
            plot_i += 1
            continue
        try:
            PartialDependenceDisplay.from_estimator(
                model_for_pdp,
                Xf,
                features=[feat],
                ax=axes[plot_i],
                percentiles=PDP_PERCENTILES
            )
        except Exception as e:
            axes[plot_i].axis('off')
        plot_i += 1

    for j in range(plot_i, len(axes)):
        fig.delaxes(axes[j])

    plt.tight_layout()
    file_path = f"{OUTPUT_DIR}/{model_name}_test_pdp.png"
    plt.savefig(file_path)
    plt.close()
    print("Saved:", file_path)

# ---------- LOAD DATA ----------
df = pd.read_csv(CSV_PATH)
if "id" in df.columns:
    df = df.drop(columns=["id"])

feature_names = df.drop(columns=["target_variable"]).columns.tolist()
X = df.drop(columns=["target_variable"])
y = df["target_variable"]

X_orig = X.copy()

scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=feature_names)

X_train_all = X_scaled.values
y_train_all = y.values


# ============================================================
#                     XGBOOST
# ============================================================
print("Training XGBoost...")

# Make sure that X_train_all is a pandas DataFrame so that it has feature names
X_train_all_df = pd.DataFrame(X_train_all, columns=feature_names)

t0 = time.time()
xgb = XGBClassifier(eval_metric="logloss", use_label_encoder=False, random_state=42)
xgb.fit(X_train_all_df, y_train_all)  # Pass the DataFrame instead of ndarray
t_xgb = time.time() - t0

y_pred_xgb = xgb.predict(X_train_all_df)  # Use DataFrame for prediction
metrics_xgb = evaluate_metrics(y_train_all, y_pred_xgb)
print_results_table("XGBoost", metrics_xgb, t_xgb)

# Feature importance
importance_dict = xgb.get_booster().get_score(importance_type="gain")
total_gain = sum(importance_dict.values()) if importance_dict else 1.0
xgb_imp = pd.DataFrame({
    "feature": feature_names,
    "importance": [importance_dict.get(f, 0)/total_gain for f in feature_names]
}).sort_values(by="importance", ascending=True)

plt.figure(figsize=(10, 0.35*len(feature_names)))
plt.barh(xgb_imp["feature"], xgb_imp["importance"], color="red")
plt.title("XGBoost Feature Importance (Normalized Gain)")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/xgboost_test_featureimportance.png")
plt.close()

# SHAP mean value graph for XGBoost
# Create SHAP explainer and compute SHAP values
explainer = shap.Explainer(xgb)
shap_values = explainer(X_train_all_df)

# Summary plot for feature importance
shap.summary_plot(shap_values, X_train_all_df, plot_type="bar")
plt.savefig(f"{OUTPUT_DIR}/xgboost_shap_summary_plot.png")
plt.close()

# PDP
save_pdp_grid("xgboost", xgb, X_orig)


# ============================================================
#                 RANDOM FOREST
# ============================================================
print("Training Random Forest...")

# Convert to DataFrame to retain feature names during training
X_train_all_df = pd.DataFrame(X_train_all, columns=feature_names)

t0 = time.time()
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=12,
    max_features="sqrt",
    n_jobs=-1,
    random_state=42,
)
rf.fit(X_train_all_df, y_train_all)  # Use DataFrame instead of ndarray
t_rf = time.time() - t0

y_pred_rf = rf.predict(X_train_all_df)  # Use DataFrame for prediction
metrics_rf = evaluate_metrics(y_train_all, y_pred_rf)
print_results_table("RandomForest", metrics_rf, t_rf)

rf_imp = pd.DataFrame({
    "feature": feature_names,
    "importance": rf.feature_importances_
}).sort_values(by="importance", ascending=True)

plt.figure(figsize=(10, 0.35*len(feature_names)))
plt.barh(rf_imp["feature"], rf_imp["importance"], color="green")
plt.title("Random Forest Feature Importance")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/randomforest_test_featureimportance.png")
plt.close()

# SHAP mean value graph for Random Forest
# Create SHAP explainer and compute SHAP values (with check_additivity=False)
explainer_rf = shap.Explainer(rf, X_train_all_df)
shap_values_rf = explainer_rf(X_train_all_df, check_additivity=False)  # Disable additivity check

# Summary plot for feature importance for Random Forest
shap.summary_plot(shap_values_rf, X_train_all_df, plot_type="bar")
plt.savefig(f"{OUTPUT_DIR}/randomforest_shap_summary_plot.png")
plt.close()

# PDP
save_pdp_grid("randomforest", rf, X_orig)


# ============================================================
#                      KNN
# ============================================================
print("Training KNN...")

# Convert to DataFrame to retain feature names during training
X_train_all_df = pd.DataFrame(X_train_all, columns=feature_names)

t0 = time.time()
knn = KNeighborsClassifier(n_neighbors=5, n_jobs=-1)
knn.fit(X_train_all_df, y_train_all)  # Use DataFrame instead of ndarray
t_knn = time.time() - t0

y_pred_knn = knn.predict(X_train_all_df)  # Use DataFrame for prediction
metrics_knn = evaluate_metrics(y_train_all, y_pred_knn)
print_results_table("KNN", metrics_knn, t_knn)

# SHAP for KNN (using KernelSHAP)
# Kernel SHAP works for KNN
explainer_knn = shap.KernelExplainer(knn.predict_proba, X_train_all_df)
shap_values_knn = explainer_knn.shap_values(X_train_all_df)

# Summary plot for KNN
shap.summary_plot(shap_values_knn, X_train_all_df, plot_type="bar")
plt.savefig(f"{OUTPUT_DIR}/knn_shap_summary_plot.png")
plt.close()

# PDP
save_pdp_grid("knn", knn, X_orig)


# ============================================================
print("\nDone. Saved files in:", OUTPUT_DIR)
for f in os.listdir(OUTPUT_DIR):
    print(" -", f)
