import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Avoid Tkinter errors in VS Code
import matplotlib.pyplot as plt
import shap
import time
import math

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.inspection import PartialDependenceDisplay

# -----------------------------
# Helper functions
# -----------------------------
def evaluate_model(model, X_test, y_test):
    preds = model.predict(X_test)
    return {
        "accuracy": accuracy_score(y_test, preds),
        "f1": f1_score(y_test, preds),
        "precision": precision_score(y_test, preds),
        "recall": recall_score(y_test, preds)
    }

def print_results_table(model_name, metrics_dict, time_taken):
    print(f"\n📊 Performance Table for {model_name}")
    print("+----------------+-----------+")
    print("| Metric         | Value     |")
    print("+----------------+-----------+")
    for metric, value in metrics_dict.items():
        print(f"| {metric.capitalize():<14} | {value:<9.4f} |")
    print(f"| Time (s)       | {time_taken:<9.2f} |")
    print("+----------------+-----------+\n")

# -----------------------------
# XGBoost Feature Importance
# -----------------------------
def plot_xgb_feature_importance(model, X_train, model_name):
    importance_dict = model.get_booster().get_score(importance_type='gain')
    importance_df = pd.DataFrame({
        "feature": list(importance_dict.keys()),
        "importance": list(importance_dict.values())
    })
    
    # Ensure all features appear
    all_features = X_train.columns.tolist()
    for f in all_features:
        if f not in importance_df['feature'].values:
            importance_df = importance_df.append({"feature": f, "importance": 0}, ignore_index=True)
    
    importance_df = importance_df.sort_values(by="importance", ascending=True)
    plt.figure(figsize=(10, 8))
    plt.barh(importance_df["feature"], importance_df["importance"], color="#0077b6")
    plt.xlabel("Importance (Gain)")
    plt.title(f"XGBoost Feature Importance ({model_name})")
    plt.tight_layout()
    plt.savefig(f"{model_name}_feature_importance.png")
    plt.close()

# -----------------------------
# Random Forest Feature Importance
# -----------------------------
def plot_rf_feature_importance(model, X_train, model_name):
    importances = model.feature_importances_
    importance_df = pd.DataFrame({"feature": X_train.columns, "importance": importances})
    importance_df = importance_df.sort_values(by="importance", ascending=True)
    
    plt.figure(figsize=(10, 8))
    plt.barh(importance_df["feature"], importance_df["importance"], color="#00b347")
    plt.xlabel("Importance")
    plt.title(f"Random Forest Feature Importance ({model_name})")
    plt.tight_layout()
    plt.savefig(f"{model_name}_feature_importance.png")
    plt.close()

# -----------------------------
# SHAP Summary Plot
# -----------------------------
def plot_shap_summary(model, X_test, model_name):
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test)
    
    shap.summary_plot(
        shap_values if isinstance(shap_values, np.ndarray) else shap_values[1],
        X_test,
        plot_type="bar",
        max_display=len(X_test.columns),
        show=False
    )
    plt.savefig(f"{model_name}_shap_summary.png")
    plt.close()
    
    return explainer, shap_values

# -----------------------------
# Partial Dependence Plots
# -----------------------------
def plot_pdp(model, X_train, model_name):
    X_train = X_train.astype(float)
    n_features = len(X_train.columns)
    cols = 3
    rows = math.ceil(n_features / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5*cols, 4*rows))
    axes = axes.flatten()

    plotted = 0
    for i, feature in enumerate(X_train.columns):
        if X_train[feature].nunique() <= 1:
            continue
        try:
            PartialDependenceDisplay.from_estimator(model, X_train, features=[feature], ax=axes[plotted])
            plotted += 1
        except ValueError as e:
            print(f"Skipping PDP for {feature} due to error: {e}")

    for j in range(plotted, len(axes)):
        fig.delaxes(axes[j])

    plt.tight_layout()
    plt.savefig(f"{model_name}_pdp_all_features.png")
    plt.close()

# -----------------------------
# Local SHAP explanation
# -----------------------------
def plot_local_shap(model, explainer, shap_values, X_test, model_name):
    y_proba = model.predict_proba(X_test)[:, 1]
    target_idx = np.argmax(y_proba)
    print(f"Local explanation for opportunity index {X_test.index[target_idx]} (predicted probability: {y_proba[target_idx]:.2f})")
    
    force_plot = shap.force_plot(
        explainer.expected_value[1] if isinstance(shap_values, list) else explainer.expected_value,
        shap_values[1][target_idx] if isinstance(shap_values, list) else shap_values[target_idx],
        X_test.iloc[target_idx,:],
        matplotlib=False
    )
    shap.save_html(f"{model_name}_local_explanation.html", force_plot)

# -----------------------------
# Load dataset
# -----------------------------
df = pd.read_csv("dataset.csv")
if 'id' in df.columns:
    df = df.drop(columns=["id"])

X = df.drop("target_variable", axis=1)
y = df["target_variable"]

# -----------------------------
# Train-test split
# -----------------------------
scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

X_train_orig, X_test_orig, y_train, y_test = train_test_split(
    X.astype(float), y, test_size=0.2, random_state=42, stratify=y
)
X_train, X_test, _, _ = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

# -----------------------------
# Train XGBoost
# -----------------------------
xgb_model = XGBClassifier(eval_metric="logloss", use_label_encoder=False, random_state=42)
print("🔧 Training XGBoost...")
start_time = time.time()
xgb_model.fit(X_train, y_train)
elapsed = time.time() - start_time
metrics = evaluate_model(xgb_model, X_test, y_test)
print_results_table("XGBoost", metrics, elapsed)

# XGBoost explainability
plot_xgb_feature_importance(xgb_model, X_train, "XGBoost")
explainer, shap_values = plot_shap_summary(xgb_model, X_test, "XGBoost")
plot_pdp(xgb_model, X_train_orig, "XGBoost")
plot_local_shap(xgb_model, explainer, shap_values, X_test, "XGBoost")

# -----------------------------
# Train Random Forest
# -----------------------------
rf_model = RandomForestClassifier(
    n_estimators=150, max_depth=12, max_features='sqrt', n_jobs=-1, random_state=42
)
print("🔧 Training Random Forest...")
start_time = time.time()
rf_model.fit(X_train, y_train)
elapsed = time.time() - start_time
metrics = evaluate_model(rf_model, X_test, y_test)
print_results_table("Random Forest", metrics, elapsed)

# Random Forest explainability
plot_rf_feature_importance(rf_model, X_train, "Random Forest")
plot_pdp(rf_model, X_train_orig, "Random Forest")

print("\n✅ All explainability plots saved. Open local XGBoost HTML for detailed local insights.")
