import os
import math
import time
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple, List

# Configurar matplotlib para que no requiera una GUI
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shap

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.inspection import PartialDependenceDisplay, permutation_importance
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# =============================================================================
# --- CONFIGURACIÓN CENTRALIZADA ---
# =============================================================================
CONFIG = {
    "data": {
        "csv_path": "dataset.csv",
        "id_column": "id",
        "target_column": "target_variable",
    },
    "output": {
        "dir": "explainability_outputs",
    },
    "model_params": {
        "test_size": 0.2,
        "random_state": 42,
    },
    "pdp": {
        "cols": 3,
        "min_unique_values": 5,
        "percentiles": (0.01, 0.99),
    },
    "plot": {
        "feature_importance_figsize": (10, 8),
        "bar_color": {
            "XGBoost": "#003f5c",
            "RandomForest": "#7a5195",
            "KNN": "#ef5675",
        }
    }
}

# =============================================================================
# --- FUNCIONES AUXILIARES ---
# =============================================================================

def load_and_preprocess_data() -> Tuple:
    """Carga los datos, los limpia, los divide y los escala."""
    print("🔄 1. Cargando y preprocesando datos...")
    df = pd.read_csv(CONFIG["data"]["csv_path"])
    
    if CONFIG["data"]["id_column"] in df.columns:
        df = df.drop(columns=[CONFIG["data"]["id_column"]])

    X = df.drop(columns=[CONFIG["data"]["target_column"]])
    y = df[CONFIG["data"]["target_column"]]
    feature_names = X.columns.tolist()

    # Dividir ANTES de escalar
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=CONFIG["model_params"]["test_size"],
        random_state=CONFIG["model_params"]["random_state"],
        stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=feature_names)
    X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=feature_names)

    print("   ... Datos listos para el entrenamiento.")
    return X_train_scaled, X_test_scaled, y_train, y_test, X_test, feature_names


def evaluate_metrics(y_true: pd.Series, y_pred: np.ndarray) -> Dict[str, float]:
    """Calcula y devuelve un diccionario de métricas de clasificación."""
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
    }

def print_results_table(model_name: str, metrics: Dict[str, float], time_taken: float):
    """Imprime una tabla formateada con las métricas de rendimiento."""
    print(f"\n📊 Tabla de Rendimiento para {model_name}")
    print("+----------------+-----------+")
    print("| Métrica        | Valor     |")
    print("+----------------+-----------+")
    for metric, value in metrics.items():
        print(f"| {metric.capitalize():<14} | {value:<9.4f} |")
    print(f"| Tiempo (s)     | {time_taken:<9.2f} |")
    print("+----------------+-----------+\n")

# =============================================================================
# --- FUNCIONES DE INTERPRETABILIDAD Y GRÁFICOS ---
# =============================================================================

def get_feature_importances(model: Any, model_name: str, X_test: pd.DataFrame, y_test: pd.Series) -> pd.DataFrame:
    """Calcula la importancia de características según el tipo de modelo."""
    if model_name in ["XGBoost", "RandomForest"]:
        importances = model.feature_importances_
    elif model_name == "KNN":
        # La permutación es más costosa, por eso se informa al usuario
        print(f"   ... Calculando importancia por permutación para {model_name}...")
        perm_imp = permutation_importance(
            model, X_test, y_test, n_repeats=10, random_state=CONFIG["model_params"]["random_state"]
        )
        importances = perm_imp.importances_mean
    else:
        # Devuelve un array vacío si el modelo no tiene un método de importancia estándar
        return pd.DataFrame({'feature': X_test.columns, 'importance': 0})
        
    return pd.DataFrame({
        'feature': X_test.columns,
        'importance': importances
    }).sort_values(by="importance", ascending=True)


def plot_feature_importance(model_name: str, importance_df: pd.DataFrame):
    """Genera y guarda un gráfico de barras de importancia de características."""
    output_path = os.path.join(CONFIG["output"]["dir"], f"{model_name}_feature_importance.png")
    
    plt.figure(figsize=CONFIG["plot"]["feature_importance_figsize"])
    plt.barh(
        importance_df["feature"],
        importance_df["importance"],
        color=CONFIG["plot"]["bar_color"].get(model_name, "#333333")
    )
    plt.title(f"Importancia de Características ({model_name})")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"   -> Gráfico de importancia guardado en: {output_path}")

def plot_shap_summary(model: Any, X_test: pd.DataFrame, model_name: str):
    """Genera y guarda un gráfico de resumen de SHAP."""
    print("   ... Calculando valores SHAP...")
    output_path = os.path.join(CONFIG["output"]["dir"], f"{model_name}_shap_summary.png")
    
    explainer = shap.Explainer(model)
    shap_values = explainer(X_test)
    
    # Crear una nueva figura para evitar sobreescrituras
    plt.figure()
    shap.summary_plot(shap_values, X_test, plot_type="bar", show=False)
    plt.tight_layout()
    plt.savefig(output_path, bbox_inches='tight')
    plt.close()
    print(f"   -> Gráfico SHAP guardado en: {output_path}")


def save_pdp_grid(model: Any, model_name: str, X_test_unscaled: pd.DataFrame):
    """Genera y guarda una cuadrícula de gráficos de Dependencia Parcial (PDP)."""
    output_path = os.path.join(CONFIG["output"]["dir"], f"{model_name}_pdp_grid.png")
    
    features = [f for f in X_test_unscaled.columns if X_test_unscaled[f].nunique() > CONFIG["pdp"]["min_unique_values"]]
    if not features:
        print("   ... Omitiendo PDP: no hay características con suficientes valores únicos.")
        return

    n_features = len(features)
    cols = CONFIG["pdp"]["cols"]
    rows = math.ceil(n_features / cols)

    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 4 * rows))
    axes = axes.flatten()

    PartialDependenceDisplay.from_estimator(
        model,
        X_test_unscaled,
        features=features,
        ax=axes[:n_features],
        percentiles=CONFIG["pdp"]["percentiles"]
    )
    
    # Ocultar ejes no utilizados
    for i in range(n_features, len(axes)):
        axes[i].axis('off')

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"   -> Cuadrícula PDP guardada en: {output_path}")

# =============================================================================
# --- FUNCIÓN PRINCIPAL DE EJECUCIÓN ---
# =============================================================================

def train_evaluate_and_explain(model: Any, model_name: str, data: Tuple):
    """
    Orquesta el entrenamiento, evaluación y generación de explicaciones
    para un único modelo.
    """
    X_train, X_test, y_train, y_test, X_test_unscaled, feature_names = data
    
    print(f"⚙️  Entrenando el modelo: {model_name}...")
    start_time = time.time()
    
    # Entrenar el modelo
    model.fit(X_train, y_train)
    
    elapsed_time = time.time() - start_time
    
    # Evaluar el modelo
    y_pred = model.predict(X_test)
    metrics = evaluate_metrics(y_test, y_pred)
    print_results_table(model_name, metrics, elapsed_time)

    # Generar gráficos de interpretabilidad
    print(f"🎨 Generando explicaciones para {model_name}...")
    
    # 1. Importancia de Características
    importance_df = get_feature_importances(model, model_name, X_test, y_test)
    plot_feature_importance(model_name, importance_df)

    # 2. Gráficos de Dependencia Parcial (PDP)
    # Usamos los datos sin escalar para que los ejes sean interpretables
    save_pdp_grid(model, model_name, X_test_unscaled)

    # 3. SHAP (solo para modelos de árbol como XGBoost)
    if model_name == "XGBoost":
        plot_shap_summary(model, X_test, model_name)


def main():
    """Punto de entrada principal del script."""
    os.makedirs(CONFIG["output"]["dir"], exist_ok=True)
    
    # Cargar y preparar los datos una sola vez
    data_splits = load_and_preprocess_data()
    
    # Definir los modelos a entrenar
    models_to_run = {
        "XGBoost": XGBClassifier(
            eval_metric="logloss",
            use_label_encoder=False,
            random_state=CONFIG["model_params"]["random_state"]
        ),
        "RandomForest": RandomForestClassifier(
            n_estimators=200,
            max_depth=12,
            max_features="sqrt",
            n_jobs=-1,
            random_state=CONFIG["model_params"]["random_state"],
        ),
        "KNN": KNeighborsClassifier(n_neighbors=5, n_jobs=-1),
    }

    # Iterar y ejecutar el flujo de trabajo para cada modelo
    for name, model in models_to_run.items():
        print("\n" + "="*50)
        train_evaluate_and_explain(model, name, data_splits)
        print("="*50)

    print(f"\n✅ Proceso completado. Todos los resultados guardados en el directorio: '{CONFIG['output']['dir']}'")

if __name__ == "__main__":
    main()